# Mary (sister of Martha)

## Facts:

Mary was a women from Bethany who followed Jesus.

* Mary had a sister named Martha and a brother named Lazarus who also followed Jesus.
* One time Jesus said that Mary had chosen what was best when she chose to listen to him teach rather than being anxious about preparing him a meal as Martha was.
* Jesus brought Mary’s brother Lazarus back to life.
* Sometime after that, while Jesus was eating in someone’s home in Bethany, Mary poured expensive perfume on his feet in order to worship him.
* Jesus praised her for doing this and said that she was preparing his body for burial.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Bethany](../names/bethany.md), [frankincense](../other/frankincense.md), [Lazarus](../names/lazarus.md), [Martha](../names/martha.md))

## Bible References:

* [John 11:1-2](rc://en/tn/help/jhn/11/01)
* [John 12:1-3](rc://en/tn/help/jhn/12/01)
* [Luke 10:38-39](rc://en/tn/help/luk/10/38)

## Word Data:

* Strong’s: G31370
