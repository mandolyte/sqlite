# Elizabeth

## Facts:

Elizabeth was the mother of John the Baptist. Her husband’s name was Zechariah.

* Zechariah and Elizabeth had never been able to have children, but in their old age, God promised Zechariah that Elizabeth would bear him a son.
* God kept his promise, and soon Zechariah and Elizabeth were able to conceive, and she gave birth to a son. They named the baby John.
* Elizabeth was also a relative of Mary, Jesus’ mother.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [John (the Baptist)](../names/johnthebaptist.md), [Zechariah (NT)](../names/zechariahnt.md))

## Bible References:

* [Luke 1:5](rc://en/tn/help/luk/01/05)
* [Luke 1:24-25](rc://en/tn/help/luk/01/24)
* [Luke 1:41](rc://en/tn/help/luk/01/41)

## Word Data:

* Strong’s: G16650
