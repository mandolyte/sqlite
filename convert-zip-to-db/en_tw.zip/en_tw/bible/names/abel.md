# Abel

## Facts:

Abel was Adam and Eve’s second son. He was Cain’s younger brother.

* Abel was a shepherd.
* Abel sacrificed some of his animals as an offering to God.
* God was pleased with Abel and his offerings.
* Adam and Eve’s firstborn son Cain murdered Abel.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Cain](../names/cain.md), [sacrifice](../other/sacrifice.md), [shepherd](../other/shepherd.md))

## Bible References:

* [Genesis 4:2](rc://en/tn/help/gen/04/02)
* [Genesis 4:9](rc://en/tn/help/gen/04/09)
* [Hebrews 12:24](rc://en/tn/help/heb/12/24)
* [Luke 11:49-51](rc://en/tn/help/luk/11/49)
* [Matthew 23:35](rc://en/tn/help/mat/23/35)

## Word Data:

* Strong’s: H1893, G00060
