# Asa

## Facts:

Asa was a king who ruled over the kingdom of Judah for forty years, from 913 B.C. to 873 B.c.

* King Asa was a good king who removed many idols of false gods and caused the Israelites to start worshiping Yahweh again.
* Yahweh gave King Asa success in his warfare against other nations.
* Later in his reign, however, King Asa stopped trusting Yahweh and became sick with a disease that eventually killed him.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

## Bible References:

* [1 Chronicles 9:14-16](rc://en/tn/help/1ch/09/14)
* [1 Kings 15:7-8](rc://en/tn/help/1ki/15/07)
* [2 Chronicles 14:3](rc://en/tn/help/2ch/14/03)
* [Jeremiah 41:9](rc://en/tn/help/jer/41/09)
* [Matthew 1:7](rc://en/tn/help/mat/01/07)

## Word Data:

* Strong’s: H0609
