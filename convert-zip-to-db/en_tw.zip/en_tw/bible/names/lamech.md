# Lamech

## Facts:

Lamech was the name of two men mentioned in the book of Genesis.

* The first Lamech mentioned was a descendant of Cain. He boasted to his two wives that he had killed a man for injuring him.
* The second Lamech was a descendant of Seth. He was also the father of Noah.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Cain](../names/cain.md), [Noah](../names/noah.md), [Seth](../names/seth.md))

## Bible References:

* [Genesis 4:18-19](rc://en/tn/help/gen/04/18)
* [Genesis 4:24](rc://en/tn/help/gen/04/24)
* [Genesis 5:25](rc://en/tn/help/gen/05/25)
* [Genesis 5:29](rc://en/tn/help/gen/05/29)
* [Genesis 5:31](rc://en/tn/help/gen/05/31)
* [Luke 3:36](rc://en/tn/help/luk/03/36)

## Word Data:

* Strong’s: H3929, G29840
