# Beth Shemesh

## Facts:

Beth Shemesh was the name of a Canaanite city approximately 30 kilometers west of Jerusalem.

* The Israelites captured Beth Shemesh during the time of Joshua’s leadership.
* Beth Shemesh was a city that was set aside as a place for the Levite priests to live.
* When the Philistines were taking the captured ark of the covenant back to Jerusalem, Beth Shemesh was the first city where they stopped with it.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [ark of the covenant](../kt/arkofthecovenant.md), [Canaan](../names/canaan.md), [Jerusalem](../names/jerusalem.md), [Joshua](../names/joshua.md), [Levite](../names/levite.md), [Philistines](../names/philistines.md))

## Bible References:

* [1 Kings 4:9](rc://en/tn/help/1ki/04/09)
* [1 Samuel 6:9](rc://en/tn/help/1sa/06/09)
* [Joshua 19:20-22](rc://en/tn/help/jos/19/20)
* [Judges 1:33](rc://en/tn/help/jdg/01/33)

## Word Data:

* Strong’s: H1053
