# Mary Magdalene

## Facts:

Mary Magdalene was one of several women who believed in Jesus and followed him in his ministry. She was known as the one whom Jesus had healed from seven demons who had controlled her.

* Mary Magdalene and some other women helped support Jesus and his apostles by giving to them.
* She is also mentioned as one of the women who were the first to see Jesus after he rose from the dead.
* As Mary Magdalene stood outside the empty tomb, she saw Jesus standing there and he told her to go tell the other disciples that he was alive again.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [demon](../kt/demon.md), [demon-possessed](../kt/demonpossessed.md))

## Bible References:

* [Luke 8:1-3](rc://en/tn/help/luk/08/01)
* [Luke 24:8-10](rc://en/tn/help/luk/24/08)
* [Mark 15:39-41](rc://en/tn/help/mrk/15/39)
* [Matthew 27:54-56](rc://en/tn/help/mat/27/54)

## Word Data:

* Strong’s: G30940, G31370
