# Enoch

## Facts:

Enoch was the name of two men in the Old Testament.

* One man named Enoch was descended from Seth. He was the great grandfather of Noah.
* This Enoch had a close relationship with God and when he was 365 years old, God took him to heaven while he was still alive.
* A different man named Enoch was a son of Cain.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Cain](../names/cain.md), [Seth](../names/seth.md))

## Bible References:

* [1 Chronicles 1:3](rc://en/tn/help/1ch/01/03)
* [Genesis 5:18-20](rc://en/tn/help/gen/05/18)
* [Genesis 5:24](rc://en/tn/help/gen/05/24)
* [Jude 1:14](rc://en/tn/help/jud/01/14)
* [Luke 3:36-38](rc://en/tn/help/luk/03/36)

## Word Data:

* Strong’s: H2585, G18020
