# Bilhah

## Facts:

Bilhah was one of Jacob’s wives. She gave birth to Dan and Naphtali, two sons of Jacob whose descendants became tribes of Israel.

* Laban gave Bilhah to Rachel as a servant when Rachel married Jacob.
* Because Rachel was not having children, she gave Bilhah to Jacob as a wife in order to produce children for her.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Jacob](../names/jacob.md), [Rachel](../names/rachel.md), [Dan](../names/dan.md), [Naphtali](../names/naphtali.md))

## Bible References:

* [Genesis 29:29](rc://en/tn/help/gen/29/29)
* [Genesis 30:4](rc://en/tn/help/gen/30/4)

## Word Data:

* Strong’s: H1090
