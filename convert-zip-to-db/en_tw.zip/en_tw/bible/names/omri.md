# Omri

## Facts:

Omri was an army commander who became the sixth king of Israel.

* King Omri reigned for twelve years in the city of Tirzah.
* Like all the kings of Israel before him, Omri was a very evil king who led the people of Israel into more idol worship.
* Omri was also the father of King Ahab.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Ahab](../names/ahab.md), [Israel](../kt/israel.md), [Jeroboam](../names/jeroboam.md), [Tirzah](../names/tirzah.md))

## Bible References:

* [2 Chronicles 22:1-3](rc://en/tn/help/2ch/22/01)

## Word Data:

* Strong’s: H6018
